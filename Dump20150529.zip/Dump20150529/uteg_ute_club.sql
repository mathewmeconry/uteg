-- MySQL dump 10.13  Distrib 5.6.23, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: uteg
-- ------------------------------------------------------
-- Server version	5.6.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ute_club`
--

DROP TABLE IF EXISTS `ute_club`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ute_club` (
  `club_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `deletedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`club_id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ute_club`
--

LOCK TABLES `ute_club` WRITE;
/*!40000 ALTER TABLE `ute_club` DISABLE KEYS */;
INSERT INTO `ute_club` VALUES (21,'BTV Aarau','0000-00-00 00:00:00',NULL),(22,'Geräteriege Schinznach-Dorf','0000-00-00 00:00:00',NULL),(23,'STV Niederwil','0000-00-00 00:00:00',NULL),(24,'Geräteriege STV Mägenwil','0000-00-00 00:00:00',NULL),(25,'Getu DTV Obersiggenthal','0000-00-00 00:00:00',NULL),(26,'TSV Rohrdorf','0000-00-00 00:00:00',NULL),(27,'STV Neuenhof','0000-00-00 00:00:00',NULL),(29,'SV Künten','0000-00-00 00:00:00',NULL),(30,'Kugetu Kleindöttingen','0000-00-00 00:00:00',NULL),(31,'Gränichen STV','0000-00-00 00:00:00',NULL),(32,'Getu Brittnau','0000-00-00 00:00:00',NULL),(33,'STV Wettingen','0000-00-00 00:00:00',NULL),(34,'STV Niederrohrdorf','0000-00-00 00:00:00',NULL),(35,'GETU Sarmenstorf','0000-00-00 00:00:00',NULL),(36,'TV Wohlen','0000-00-00 00:00:00',NULL),(37,'Geräteturnen Möhlin','0000-00-00 00:00:00',NULL),(38,'STV Mägenwil','0000-00-00 00:00:00',NULL),(39,'Getu Uerkheim','0000-00-00 00:00:00',NULL),(40,'Getu Wölflinswil','0000-00-00 00:00:00',NULL),(41,'Geräteriege Urdorf','0000-00-00 00:00:00',NULL),(42,'GeTu Würenlingen','0000-00-00 00:00:00',NULL),(43,'TV Wolfwil','0000-00-00 00:00:00',NULL),(44,'TV Lenzburg','0000-00-00 00:00:00',NULL),(45,'DTV Steinhausen','0000-00-00 00:00:00',NULL),(46,'Turnfabrik (STV Frauenfeld)','0000-00-00 00:00:00',NULL),(47,'DTV Ehrendingen Jugend','0000-00-00 00:00:00',NULL),(48,'BTV Luzern','0000-00-00 00:00:00',NULL),(49,'STV Sulz','0000-00-00 00:00:00',NULL),(50,'Geräteriege Koblenz','0000-00-00 00:00:00',NULL),(51,'DTV Wettingen','0000-00-00 00:00:00',NULL),(52,'pause','0000-00-00 00:00:00',NULL),(54,'STV Würenlingen','0000-00-00 00:00:00',NULL),(55,'TV Sarmenstorf','0000-00-00 00:00:00',NULL);
/*!40000 ALTER TABLE `ute_club` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-05-29 18:05:57
